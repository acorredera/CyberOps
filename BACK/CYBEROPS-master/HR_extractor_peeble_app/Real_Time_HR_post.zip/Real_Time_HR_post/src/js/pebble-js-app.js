/*
 * Copyright (c) 2016-2017, Natacha Porté
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * More info about Pebble.js(how to programme Pebble apps using JS) in: https://github.com/pebble/pebblejs
 * and other pages: https://developer.rebble.io/developer.pebble.com/docs/index.html
 * The Pebble object from PebbleKit JavaScript is available as a global variable
 */
// var resource = require('./node_modules/myExtraFile');        // require additional library
//
// console.log(resource.area(4));                  // logs 42

//resource.functionA();                         // logs "This is working now"




// console.log("kafka  no cargado");
// //var kafka = require('./node_modules/kafka-node/kafka');
// console.log("kafka cargado");
var cfg_endpoint = "";//"http://192.168.1.33:3000/post/";
var cfg_data_field = null;
var cfg_bundle_max = 1;
var cfg_bundle_separator = "\r\n";
var cfg_sending_data_rate = null; // minutes
var cfg_employee_alias = "";

var to_send = []; //data to send
var senders = new XMLHttpRequest();
var bundle_size = 0;

//SendPayload & sendHead are in charge of sending data received from the watch to the server(endpoint url)
function sendPayload(payload) {
    //var data = encodeURIComponent(cfg_data_field) + '=' + encodeURIComponent(payload);
   var data  = '{"' + cfg_data_field + '"' + ':' + '"' + payload + ','+cfg_employee_alias+'"'; //', '+cfg_employee_alias+
   data += "}";
   console.log('ENVIANDO::: '+data);
   senders.open("POST", cfg_endpoint, true);
   senders.setRequestHeader('Content-type', 'application/json', 'charset=UTF-8');
   senders.send((decodeURIComponent(data)));
}

function sendHead() {
   if (to_send.length < 1) return;
   bundle_size = 0;
   var payload = [];
   while (bundle_size < cfg_bundle_max && bundle_size < to_send.length) {
      payload.push(to_send[bundle_size].split(";")[1]);
      bundle_size += 1;
   }
   sendPayload(payload.join(cfg_bundle_separator));
}

function enqueue(key, line) {
   to_send.push(key + ";" + line);
   localStorage.setItem("toSend", to_send.join("|")); //data|data|data| ....
   localStorage.setItem("lastSent", key);
   if (to_send.length === 1) {
      Pebble.sendAppMessage({ "uploadStart": parseInt(key, 10) }); //send to the watch the info about the starting of the sending data to server
      sendHead();//send data to server
   }
}

function uploadDone() {
   if (bundle_size > 1) {
      to_send.splice(0, bundle_size - 1);
   }
   var sent_key = to_send.shift().split(";")[0];
   localStorage.setItem("toSend", to_send.join("|"));
   Pebble.sendAppMessage({ "uploadDone": parseInt(sent_key, 10) });
   sendHead();
}

function uploadError() {
   console.log(this.statusText);
   Pebble.sendAppMessage({ "uploadFailed": this.statusText });
}

senders.addEventListener("load", uploadDone);
senders.addEventListener("error", uploadError);


// 'ready' - The watchapp has been launched and the PebbleKit JS component is now ready to receive events.
Pebble.addEventListener("ready", function() {
   console.log("Health Export PebbleKit JS ready!");
   var str_to_send = localStorage.getItem("toSend");
   to_send = str_to_send ? str_to_send.split("|") : [];

   cfg_endpoint = localStorage.getItem("cfgEndpoint");
   cfg_data_field = localStorage.getItem("cfgDataField");
   cfg_sending_data_rate = parseInt(localStorage.getItem("cfgSendingDataRate")|| "60", 10);//60 by default if there is no dta previously saved
   cfg_bundle_max = parseInt(localStorage.getItem("cfgBundleMax") || "1", 10); //1 by default if there is no dta previously saved
   cfg_bundle_separator = localStorage.getItem("cfgBundleSeparator");
   cfg_employee_alias = localStorage.getItem("cfgEmployeeAlias");

   if (!(cfg_bundle_max >= 1)) cfg_bundle_max = 1;
   //Prepare message to send to the app running on the watch. All the messages should be
    // JSON objects containing key-value pairs.
    //if we have configured the device( acceded to the config webpage: (https://cristinalunaj.github.io/HRConfiguration/)
    //obtain the last sent message , if not, message of not configuration
   var msg = {};
   if (cfg_endpoint && cfg_data_field) {
      msg.lastSent = parseInt(localStorage.getItem("lastSent") || "0", 10);
   } else {
      msg.modalMessage = "Not configured";
   }
   //If we have data to send, we extract the first value to send and send it to the watch app that is running...
    //qué valor es???
   if (to_send.length >= 1) {
      msg.uploadStart = parseInt(to_send[0].split(";")[0]);
   }
   Pebble.sendAppMessage(msg); //sending MSG_KEY_UPLOAD_START signal, received in the watch
    //...the other part of the data is sent to the server introduced in endpoint url, in the config webpage
   if (to_send.length >= 1) {
      sendHead();
   }
});


//'appmessage' - The watch sent an AppMessage to PebbleKit JS
Pebble.addEventListener("appmessage", function(e) {
   if (e.payload.dataKey && e.payload.dataLine) { //Tuple key,value sent from the watch that enters in the queue to send them to the server
      enqueue(e.payload.dataKey, e.payload.dataLine);
   }
});


//Send request to the webpage: https://cristinalunaj.github.io/HRConfiguration/  , & pass the parameters url and data_field if they exist
// 'showConfiguration' - The user has requested the app's configuration webview to be displayed.
// This can occur either upon the app's initial install or when the user taps 'Settings'
// in the 'My Pebble' view within the phone app.
Pebble.addEventListener("showConfiguration", function() {
   var settings = "?v=1.1";
   console.log('Entramos en configuración y conectamos con la web...');
   Pebble.sendAppMessage({ "cfgStart": 1 });
   console.log('Despues de enviar config start flag..');
   if (cfg_endpoint) {
      settings += "&url=" + encodeURIComponent(cfg_endpoint);
   }
   if (cfg_data_field) {
      settings += "&data_field=" + encodeURIComponent(cfg_data_field);
   }
   if(cfg_sending_data_rate){
      settings +="&sending_frequency=" + encodeURIComponent(cfg_sending_data_rate);
      //cfg_sending_data_rate = parseInt(localStorage.getItem("cfgSendingDataRate")
   }
   if(cfg_employee_alias){
      settings +="&employee_alias=" + encodeURIComponent(cfg_employee_alias);
   }
   console.log('Entramos en configuración y conectamos con la web...');
   Pebble.openURL("https://cristinalunaj.github.io/HRConfiguration/" + settings);
});


//'webviewclosed' - The configuration webview was closed by the user. If the webview had a response,
// it will be contained in the response property (i.e: event.response).
// This response can be used to feed back user preferences to the watchapp.
Pebble.addEventListener("webviewclosed", function(e) {
   var configData = JSON.parse(e.response); //Data obtained from the configuration form
   var wasConfigured = (cfg_endpoint && cfg_data_field);
   var msg = {};
   console.log('cERRAMOS CONFIG...')
   //Parameters obtained by the config webpage and saved 'in local' for other sessions
   if (configData.url) {
      console.log("Añadido url");
      cfg_endpoint = decodeURIComponent(configData.url);
      localStorage.setItem("cfgEndpoint", cfg_endpoint);
   }
   if (configData.dataField) {
      console.log("Añadido DATA FIELD");
      cfg_data_field = configData.dataField;
      localStorage.setItem("cfgDataField", cfg_data_field);
   }
   if (configData.employeeAlias) {
      console.log("Añadido employee alias");
      cfg_employee_alias = configData.employeeAlias;
      localStorage.setItem("cfgEmployeeAlias", cfg_employee_alias);
   }
   if(configData.sendingFrequency){
      cfg_sending_data_rate = parseInt(configData.sendingFrequency,10);
      localStorage.setItem("cfgSendingDataRate", cfg_sending_data_rate);
      msg.cfgSendingDataRate = cfg_sending_data_rate;
      Pebble.sendAppMessage(msg);
   }
   msg = { "cfgEnd": 1 };
   //Parameters added by default...
   localStorage.setItem("cfgBundleMax", "1");
   localStorage.setItem("cfg_bundle_separator",  "\r\n");
   if (!wasConfigured && cfg_endpoint && cfg_data_field) {
      msg.lastSent = 0;
   }
   Pebble.sendAppMessage(msg); //Send MSG_KEY_LAST_SENT or MSG_KEY_CFG_SENDING_DATA_RATE to the watch for sending new data
});
