/*
 * Copyright (c) 2018, Cristina Luna
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * Part of the code was extracted from the pebble examples: hrm-activity-example & from faelys/pebble-health-export,
 * availables in github: https://github.com/pebble-examples/hrm-activity-example   (18/Oct/2018) &
 * https://github.com/faelys/pebble-health-export    (18/Oct/2018)
 */
#include <pebble.h>
#include <inttypes.h>
#include "dict_tools.h"

//Keys for having access to the dictionaries sent by the app.js, they have to have also a correspondence in package.json

#define MSG_KEY_LAST_SENT	110 //Key for the last sent
#define MSG_KEY_MODAL_MESSAGE	120 //key for the information/modal message

#define MSG_KEY_UPLOAD_DONE	    130 //data uploaded correctly
#define MSG_KEY_UPLOAD_START	140 //starting data upload
#define MSG_KEY_UPLOAD_FAILED	150 //upload finished

#define MSG_KEY_DATA_KEY	210 //key for sending the data key
#define MSG_KEY_DATA_LINE	220 //key for sending a new line of data

#define MSG_KEY_CFG_START	301 //start configuration
#define MSG_KEY_CFG_END		302 //end of the configuration

#define MSG_KEY_CFG_SENDING_DATA_RATE	310 //key for sending the data rate parameter


const char START_ACTIVITY_STRING[] = "Press SELECT\n to START sending data";
const char END_ACTIVITY_STRING[] = "Press SELECT\n to END sending data";
const char WAIT_JS[] = "";

//Possibles states of the sending app
typedef enum SendingState {
  STATE_NOT_STARTED,
  STATE_IN_PROGRESS,
  STATE_FINISHED
} SendingState;

//View variables
static Window *s_window;

static TextLayer *s_status_text_layer;
static TextLayer *s_bpm_text_layer;
static TextLayer *s_ctime_text_layer;

static TextLayer *s_title_text_layer;
static TextLayer *s_total_time_text_layer;
static TextLayer *s_min_bpm_text_layer;
static TextLayer *s_max_bpm_text_layer;
static TextLayer *s_send_text_layer;
//app variables
static SendingState s_app_state = STATE_NOT_STARTED;

static time_t s_start_time, s_end_time, s_last_time_sent;

static uint16_t s_curr_hr = 0;
static uint32_t s_min_hr = 65535; // max uint32_t
static uint32_t s_max_hr = 0;

static uint32_t s_hr_samples = 0;
static uint32_t s_hr_total = 0;
static int cfg_sending_data_rate;

static char global_buffer[1024];
static bool configuring = false;
static bool sending_data = false;
static int32_t last_key = 0;


int16_t get_min_hr() {
  return s_min_hr;
}

int16_t get_max_hr() {
  return s_max_hr;
}

int16_t get_avg_hr() {
  if (s_hr_samples == 0) return 0;
  return s_hr_total / s_hr_samples;
}

/*Handle of the heart rate event - Store the current heart rate when there is a change in the heart rate*/
static void prv_on_health_data(HealthEventType type, void *context) {
  // If the update was from the Heart Rate Monitor, update it
  if (type == HealthEventHeartRateUpdate) {
    s_curr_hr = (int16_t) health_service_peek_current_value(HealthMetricHeartRateBPM);
    APP_LOG(APP_LOG_LEVEL_INFO, "EVENTO HR CAMBIO: %" PRIu16, s_curr_hr);
    // Update our metrics
    if (s_curr_hr < s_min_hr) s_min_hr = s_curr_hr;
    if (s_curr_hr > s_max_hr) s_max_hr = s_curr_hr;
    s_hr_samples++;
    s_hr_total += s_curr_hr;
  }
}

/* get_data_image - fill a buffer with CSV data without line terminator */
/*    format: RFC-3339 time, heart rate*/
static uint32_t
get_data_image(char *buffer, size_t size, uint32_t data, struct tm *tick_time) {
    if (!buffer || !data) return 0;
    size_t ret;
    //Looking for errors -- If the conversion of the time is not possible
    if (!tick_time) {
		APP_LOG(APP_LOG_LEVEL_ERROR,
		    "Unable to get UTC time for ...");
		return 0;
	}
    //Introduce time in the buffer
    ret = strftime(buffer, size, "%FT%TZ", tick_time);
    //Looking for errors -- Check that the insertion of the time in the buffer has finiched successfully
    if (!ret) {
		APP_LOG(APP_LOG_LEVEL_ERROR,
		    "Unable to build RFC-3339 representation of ...");
		return 0;
	}
	if (ret >= size) {
		APP_LOG(APP_LOG_LEVEL_ERROR,
		    "Unexpected return value %zu of strftime on buffer %zu",
		    ret, size);
		return 0;
	}
    //Copy data info into the buffer:
    int i = snprintf(buffer + ret, size - ret,
	    ",%" PRIu16, s_curr_hr);
    //Looking for errors -- if there is a fail when we add the data into the buffer
    if (i <= 0) {
		APP_LOG(APP_LOG_LEVEL_ERROR, "data_image: "
		    "Unexpected return value %d of snprintf", i);
		return 0;
	}
    return ret+i;
}



/* Function that send the HR data to the server*/
static void
send_data(uint32_t data, int32_t key) {
	//int32_t int_key = key / cfg_sending_data_rate; //the key is the number of sent message and we calculate it based ont he sending period
	AppMessageResult msg_result;
	DictionaryIterator *iter;
	msg_result = app_message_outbox_begin(&iter); //message that will contain all the data to send to the mobile
	if (msg_result) {
		APP_LOG(APP_LOG_LEVEL_ERROR,
		    "send_minute_data: app_message_outbox_begin returned %d",
		    (int)msg_result);
		return;
	}
    APP_LOG(APP_LOG_LEVEL_INFO, "VAMOS A ENVIAR DATOS.... ");
	DictionaryResult dict_result;
	dict_result = dict_write_int(iter, MSG_KEY_DATA_KEY, &key, sizeof key, true); //key that the message will contain(just a counter of messages)
	if (dict_result != DICT_OK) {
		APP_LOG(APP_LOG_LEVEL_ERROR,
		    "send_minute_data: [%d] unable to add data key %" PRIi32,
		    (int)dict_result, key);
	}
	dict_result = dict_write_cstring(iter,MSG_KEY_DATA_LINE, global_buffer); //data that the message will contain (the global_buffer was filled previously with the heart rate info)
	if (dict_result != DICT_OK) {
		APP_LOG(APP_LOG_LEVEL_ERROR,
		    "send_minute_data: [%d] unable to add data line \"%s\"",
		    (int)dict_result, global_buffer);
	}
	msg_result = app_message_outbox_send(); //send the message
	if (msg_result) {
		APP_LOG(APP_LOG_LEVEL_ERROR,
		    "send_minute_data: app_message_outbox_send returned %d",
		    (int)msg_result);
	}
}

/* Handler of the time, that start the process of sending data with SENDING_DATA_RATE period*/
static void prv_on_activity_tick(struct tm *tick_time, TimeUnits units_changed) {
  // Update Time
  time_t current_moment = time(NULL);

  //UPDATE WATCH-TIME:
  /** Display the Time **/
  static char s_ctime_buffer[24];
  strftime(s_ctime_buffer, sizeof(s_ctime_buffer), "%FT%TZ", tick_time);
  text_layer_set_text(s_ctime_text_layer, s_ctime_buffer);

  // Update BPM
  static char s_hrm_buffer[8];
  snprintf(s_hrm_buffer, sizeof(s_hrm_buffer), "%lu BPM", (uint32_t) s_curr_hr);
  text_layer_set_text(s_bpm_text_layer, s_hrm_buffer);

  //SEND HR AND TIME Each stablished period (Taken from the app or 60 seconds)
  int32_t sending_moment = (current_moment-s_last_time_sent);  //time in seconds
  APP_LOG(APP_LOG_LEVEL_ERROR,"HT - SENDING MOMENT: %" PRIi32,sending_moment);
  APP_LOG(APP_LOG_LEVEL_ERROR,"HT - SENDING PERIOD: %i",cfg_sending_data_rate);
  if((sending_moment>=cfg_sending_data_rate) && sending_data){
    APP_LOG(APP_LOG_LEVEL_DEBUG, "HANDLE TIME: SEND DATA");
    //Create image of the data -> save data in buffer for sending it
    get_data_image(global_buffer,sizeof(global_buffer), s_curr_hr, tick_time);
    s_last_time_sent = current_moment;
    //Send data
    send_data(s_curr_hr, last_key+1);
  }
}

/*Move to the second screen and start to send data every sending date period*/
static void prv_start_activity(void) {
  // Update application state
  s_app_state = STATE_IN_PROGRESS;
  s_start_time = time(NULL);
  s_last_time_sent = s_start_time;
  sending_data = true;

  // Set min heart rate sampling period
  #if PBL_API_EXISTS(health_service_set_heart_rate_sample_period)
  health_service_set_heart_rate_sample_period(60);
  #endif

  // Update UI
  text_layer_set_text(s_status_text_layer, END_ACTIVITY_STRING);
  text_layer_set_text(s_send_text_layer, "Sending Data...");
  layer_set_hidden(text_layer_get_layer(s_ctime_text_layer), false);
  layer_set_hidden(text_layer_get_layer(s_bpm_text_layer), false);
  layer_set_hidden(text_layer_get_layer(s_send_text_layer), false);
}

/*Move to the third screen that shows a summary of the heart rate data (Possible to remove this part in future versions)*/
static void prv_end_activity(void) {
  // Update application state
  s_app_state = STATE_FINISHED;
  s_end_time = time(NULL);
  sending_data = false;
  // Set default heart rate sampling period
  #if PBL_API_EXISTS(health_service_set_heart_rate_sample_period)
  health_service_set_heart_rate_sample_period(0);
  #endif

  // Unsubscribe from tick handler
  tick_timer_service_unsubscribe();

  // Unsubscribe from health handler
  health_service_events_unsubscribe();

  // Update UI
  layer_set_hidden(text_layer_get_layer(s_ctime_text_layer), true);
  layer_set_hidden(text_layer_get_layer(s_status_text_layer), true);
  layer_set_hidden(text_layer_get_layer(s_bpm_text_layer), true);
  layer_set_hidden(text_layer_get_layer(s_send_text_layer), true);

  static char s_time_buffer[16];
  time_t diff = s_end_time - s_start_time;
  struct tm *diff_time = gmtime(&diff);

  if (diff > SECONDS_PER_HOUR) {
    strftime(s_time_buffer, sizeof(s_time_buffer), "Time: %H:%M:%S", diff_time);
  } else {
    strftime(s_time_buffer, sizeof(s_time_buffer), "Time: %M:%S", diff_time);
  }
  text_layer_set_text(s_total_time_text_layer, s_time_buffer);

  static char s_avg_bpm_buffer[16];
  snprintf(s_avg_bpm_buffer, sizeof(s_avg_bpm_buffer), "Avg: %u BPM", get_avg_hr());
  text_layer_set_text(s_send_text_layer, s_avg_bpm_buffer);

  static char s_max_bpm_buffer[16];
  snprintf(s_max_bpm_buffer, sizeof(s_max_bpm_buffer), "Max: %u BPM", get_max_hr());
  text_layer_set_text(s_max_bpm_text_layer, s_max_bpm_buffer);

  static char s_min_bpm_buffer[16];
  snprintf(s_min_bpm_buffer, sizeof(s_min_bpm_buffer), "Min: %u BPM", get_min_hr());
  text_layer_set_text(s_min_bpm_text_layer, s_min_bpm_buffer);

  layer_set_hidden(text_layer_get_layer(s_title_text_layer), false);
  layer_set_hidden(text_layer_get_layer(s_total_time_text_layer), false);
  layer_set_hidden(text_layer_get_layer(s_send_text_layer), false);
  layer_set_hidden(text_layer_get_layer(s_min_bpm_text_layer), false);
  layer_set_hidden(text_layer_get_layer(s_max_bpm_text_layer), false);
}

/*Handle for adding functionality to the select button*/
static void prv_select_click_handler(ClickRecognizerRef recognizer, void *context) {
  switch (s_app_state) {
    case STATE_NOT_STARTED:
      // Display activity
      prv_start_activity();
      break;
    case STATE_IN_PROGRESS:
      // Display Metrics
      prv_end_activity();
      break;
    default:
      // Quit
      window_stack_pop(true);
      break;
  }
}

/**/
static void
handle_last_sent(Tuple *tuple) {
	uint32_t ikey = 0;
	if (tuple->length == 4 && tuple->type == TUPLE_UINT)
		ikey = tuple->value->uint32;
	else if (tuple->length == 4 && tuple->type == TUPLE_INT)
		ikey = tuple->value->int32;
	else {
		APP_LOG(APP_LOG_LEVEL_ERROR,
		    "Unexpected type %d or length %" PRIu16
		    " for MSG_KEY_LAST_SENT",
		    (int)tuple->type, tuple->length);
		return;
	}
	APP_LOG(APP_LOG_LEVEL_INFO, "received LAST_SENT %" PRIu32, ikey);
}

/* Function for adding text to the s_send_text_layer*/
//static void
//set_sending_data_message(const char *msg) {
//    static char s_send_text_buffer[100];
//    snprintf(s_send_text_buffer, sizeof(s_send_text_buffer), "%s ", msg);
//    text_layer_set_text(s_send_text_layer, s_send_text_buffer);
//}

/* Messages handlers: This function handle the tuples that comes from the inbox_received_handler (configuration, ACKs...)*/
static void
handle_received_tuple(Tuple *tuple) { //Inbox messages
	switch (tuple->key) {
	    case MSG_KEY_LAST_SENT:
            APP_LOG(APP_LOG_LEVEL_DEBUG,
                    "LAST SETNT");
            handle_last_sent (tuple);
		break;

	    case MSG_KEY_MODAL_MESSAGE:
		if (tuple->type != TUPLE_CSTRING) {
			APP_LOG(APP_LOG_LEVEL_ERROR,
			    "Unexpected type %d for MSG_KEY_MODAL_MESSAGE",
			    (int)tuple->type);
		} else {
			APP_LOG(APP_LOG_LEVEL_DEBUG,
			    "MODAL MESSAGE..");
		}
		break;

	    case MSG_KEY_UPLOAD_DONE:
	        APP_LOG(APP_LOG_LEVEL_DEBUG,
			    "DONE UPLOAD");
		break;

	    case MSG_KEY_UPLOAD_START:
                APP_LOG(APP_LOG_LEVEL_DEBUG,
			    "UPLOAD START");
            if(!s_start_time){
                s_start_time = time(NULL);
            }

		break;

	    case MSG_KEY_UPLOAD_FAILED:
            if (tuple->type == TUPLE_CSTRING) {
                APP_LOG(APP_LOG_LEVEL_DEBUG,"UPLOAD FAILED");
            }
		break;

		case MSG_KEY_CFG_SENDING_DATA_RATE:
            cfg_sending_data_rate = tuple_int(tuple);
            persist_write_int(MSG_KEY_CFG_SENDING_DATA_RATE, cfg_sending_data_rate);
            APP_LOG(APP_LOG_LEVEL_INFO,
                "wrote cfg_sending_data_rate %i", cfg_sending_data_rate);
		break;

	    case MSG_KEY_CFG_START:
            APP_LOG(APP_LOG_LEVEL_INFO, "Starting configuration");
            configuring = true;
		break;

	    case MSG_KEY_CFG_END:
            APP_LOG(APP_LOG_LEVEL_INFO, "End of configuration");
            configuring = false;
		break;

	    default:
            APP_LOG(APP_LOG_LEVEL_ERROR,"Unknown key %lu in received message",(unsigned long)tuple->key);
	}
}

/* Function that receive data from the js and send it to the tuple handler (handle_received_tuple)*/
static void
inbox_received_handler(DictionaryIterator *iterator, void *context) { //Inbox messages
	Tuple *tuple;
	(void)context;
	for (tuple = dict_read_first(iterator);
	    tuple;
	    tuple = dict_read_next(iterator))
		handle_received_tuple(tuple);
}

static void
outbox_failed_handler(DictionaryIterator *iterator, AppMessageResult reason,
    void *context) {
	(void)iterator;
	(void)context;
	APP_LOG(APP_LOG_LEVEL_ERROR, "Outbox failed: 0x%x", (unsigned)reason);
}

static void
outbox_sent_handler(DictionaryIterator *iterator, void *context) {
	(void)iterator;
	(void)context;
}

//Configuration and others...
static void prv_click_config_provider(void *context) {
  window_single_click_subscribe(BUTTON_ID_SELECT, prv_select_click_handler);
}

static void prv_window_load(Window *window) {
  Layer *window_layer = window_get_root_layer(window);
  GRect bounds = layer_get_bounds(window_layer);

  // Determin how we launched (automaticaly start activity on quick launch)
  bool quick_launch = launch_reason() == APP_LAUNCH_QUICK_LAUNCH;

  // Status
  s_status_text_layer = text_layer_create(GRect(0, 67, bounds.size.w, 40));
  text_layer_set_text(s_status_text_layer, quick_launch ? END_ACTIVITY_STRING
                                                        : START_ACTIVITY_STRING);
  text_layer_set_text_alignment(s_status_text_layer, GTextAlignmentCenter);
  layer_set_hidden(text_layer_get_layer(s_status_text_layer), false);
  layer_add_child(window_layer, text_layer_get_layer(s_status_text_layer));

  // Current Time (day/hour/min/seconds)(Hidden)
  s_ctime_text_layer = text_layer_create(GRect(0, 27, bounds.size.w, 40));
  text_layer_set_text(s_ctime_text_layer, "00:00");
  text_layer_set_text_alignment(s_ctime_text_layer, GTextAlignmentCenter);
  layer_set_hidden(text_layer_get_layer(s_ctime_text_layer), !quick_launch);
  layer_add_child(window_layer, text_layer_get_layer(s_ctime_text_layer));


  // Curr BPM (hidden)
  s_bpm_text_layer = text_layer_create(GRect(0, 117, bounds.size.w, 20));
  text_layer_set_text(s_bpm_text_layer, "??? BPM");
  text_layer_set_text_alignment(s_bpm_text_layer, GTextAlignmentCenter);
  layer_set_hidden(text_layer_get_layer(s_bpm_text_layer), !quick_launch);
  layer_add_child(window_layer, text_layer_get_layer(s_bpm_text_layer));


  // "Workout Summay" (Hidden)
  s_title_text_layer = text_layer_create(GRect(0, 10, bounds.size.w, 20));
  text_layer_set_text(s_title_text_layer, "Data Summary");
  text_layer_set_text_alignment(s_title_text_layer, GTextAlignmentCenter);
  layer_set_hidden(text_layer_get_layer(s_title_text_layer), true);
  layer_add_child(window_layer, text_layer_get_layer(s_title_text_layer));

  // Total Time (Hidden)
  s_total_time_text_layer = text_layer_create(GRect(0, 35, bounds.size.w, 20));
  text_layer_set_text_alignment(s_total_time_text_layer, GTextAlignmentCenter);
  layer_set_hidden(text_layer_get_layer(s_total_time_text_layer), true);
  layer_add_child(window_layer, text_layer_get_layer(s_total_time_text_layer));

  // Sending layer
  s_send_text_layer = text_layer_create(GRect(0, 95, bounds.size.w, 20));
  text_layer_set_text_alignment(s_send_text_layer, GTextAlignmentCenter);
  layer_set_hidden(text_layer_get_layer(s_send_text_layer), false);
  layer_add_child(window_layer, text_layer_get_layer(s_send_text_layer));
  text_layer_set_text(s_send_text_layer, WAIT_JS);

  // Max BPM (Hidden)
  s_max_bpm_text_layer = text_layer_create(GRect(0, 110, bounds.size.w, 20));
  text_layer_set_text_alignment(s_max_bpm_text_layer, GTextAlignmentCenter);
  layer_set_hidden(text_layer_get_layer(s_max_bpm_text_layer), true);
  layer_add_child(window_layer, text_layer_get_layer(s_max_bpm_text_layer));

  // Min BPM (Hidden)
  s_min_bpm_text_layer = text_layer_create(GRect(0, 135, bounds.size.w, 20));
  text_layer_set_text_alignment(s_min_bpm_text_layer, GTextAlignmentCenter);
  layer_set_hidden(text_layer_get_layer(s_min_bpm_text_layer), true);
  layer_add_child(window_layer, text_layer_get_layer(s_min_bpm_text_layer));

  if(quick_launch) prv_start_activity();
}

static void prv_window_unload(Window *window) {
  sending_data = false;
  text_layer_destroy(s_status_text_layer);
  text_layer_destroy(s_ctime_text_layer);
  text_layer_destroy(s_bpm_text_layer);

  text_layer_destroy(s_title_text_layer);
  text_layer_destroy(s_send_text_layer);
  text_layer_destroy(s_max_bpm_text_layer);
  text_layer_destroy(s_min_bpm_text_layer);
}


static void prv_deinit(void) {
  window_destroy(s_window);

  // Reset Heart Rate Sampling
  #if PBL_API_EXISTS(health_service_set_heart_rate_sample_period)
  health_service_set_heart_rate_sample_period(0);
  #endif
}

static void prv_init(void) {

  //strncpy(modal_text, "Waiting for JS part", sizeof modal_text);
  cfg_sending_data_rate = (persist_read_int(MSG_KEY_CFG_SENDING_DATA_RATE));
  if(!cfg_sending_data_rate || cfg_sending_data_rate==0){
    cfg_sending_data_rate = 60;
  }
   APP_LOG(APP_LOG_LEVEL_DEBUG, "cfg_send_data_rate: %i", cfg_sending_data_rate);
  //Initialization of handlers for sending/receive data between phone-pebbleWatch:
  //The Inbox receives messages from the phone on the watch. Phone ---> watch
  //The Outbox sends messages from the watch to the phone. Watch ----> phone
  app_message_register_inbox_received(inbox_received_handler);
  app_message_register_outbox_failed(outbox_failed_handler);
  app_message_register_outbox_sent(outbox_sent_handler);
  // Definition of the inbox and outbox size.
  //**An ingoing (outgoing) message larger than the inbox (outbox) will not be transmitted and will generate an error.
  app_message_open(256, 2048);
  s_window = window_create();
  window_set_click_config_provider(s_window, prv_click_config_provider);

  bool success=false;
  // Set min heart rate sampling period (i.e. fastest sampling rate)
  #if PBL_API_EXISTS(health_service_set_heart_rate_sample_period)
    success = health_service_set_heart_rate_sample_period(60); //SAMPLING RATE = 1 SAMPLE PER SECOND | time in sec: desired interval between heart rate reading updates. Pass 0 to go back to automatically chosen intervals.
  #endif

  if(!success){
    prv_deinit();
  }

  window_set_window_handlers(s_window, (WindowHandlers) {
    .load = prv_window_load,
    .unload = prv_window_unload,
  });

  // Subscribe to tick handler to update display
  tick_timer_service_subscribe(SECOND_UNIT, prv_on_activity_tick);
  // Subscribe to health handler
  health_service_events_subscribe(prv_on_health_data, NULL);
  window_stack_push(s_window, true);
}


int main(void) {
  prv_init();
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Done initializing, pushed window: %p", s_window);
  app_event_loop();
  prv_deinit();
  APP_LOG(APP_LOG_LEVEL_DEBUG, "END APP RT_HR_POST");
}
