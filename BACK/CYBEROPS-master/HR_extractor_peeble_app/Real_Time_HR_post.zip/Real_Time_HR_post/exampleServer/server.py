import os,sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import NewsCore.dao.NewsDAOImpl as DAO
from flask import Flask, redirect, url_for
from flask import request
from flask_cors import CORS
from flask_jsonpify import jsonify
from flask_restful import Api
from flask import render_template
import numpy as np


app = Flask(__name__) #http://flask.pocoo.org/docs/1.0/api/
api = Api(app)

CORS(app)

@app.route("/post/", methods=['POST'])
def doPOST_HR3():
    if request.method == 'POST':
        print('post3')
        a = np.array([0,0])
        data = request.json['data']
        metricsObtained = data.split(',')
        timestamp = metricsObtained[0]
        HR = metricsObtained[-1]
        print(timestamp+",hr:"+HR)
        return ""



if __name__ == '__main__':
   app.run(host='0.0.0.0',port=3000)